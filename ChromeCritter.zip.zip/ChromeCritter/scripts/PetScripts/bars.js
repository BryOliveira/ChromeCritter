document.getElementById("nameBtn").addEventListener("click", getName);

function getName() {
	document.getElementById("nameInpt").style.display = "none";
	document.getElementById("nameBtn").style.display = "none";
	var x = document.getElementById("nameInpt").value;
	document.getElementById("name").innerHTML = x;
	document.getElementById("name").style.display = "block";

}