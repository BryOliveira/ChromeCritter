onload = function() {
	var c1 = localStorage.getItem("cellOne");
	var c2 = localStorage.getItem("cellTwo");
	var c3 = localStorage.getItem("cellThree");

	if (c1 != null) {
		var display = document.getElementById("display");
		var newRow = display.insertRow(1);
		var cell1 = newRow.insertCell(0);
		var cell2 = newRow.insertCell(1);
		var cell3 = newRow.insertCell(2);
		var cell4 = newRow.insertCell(3);
		var checkbox = document.createElement("INPUT");
		checkbox.type = "checkbox";

		cell4.style.textAlign = "center";

		cell1.innerHTML = c1;
		cell2.innerHTML = c2;
		cell3.innerHTML = c3;
		cell4.appendChild(checkbox);
	}
};