document.getElementById("entry").addEventListener("click", displayDetails);
document.getElementById("confirm").addEventListener("click", chooseDog);
var row = 1;
var homework;
var dueDate;
var className;

function displayDetails() {
	homework = document.getElementById("homework").value;
	dueDate = document.getElementById("dueDate").value;
	className = document.getElementById("classInput").value;
	if (homework == "" || dueDate == "" || className == "")
		alert("Please fill all the boxes");
	else {
		var display = document.getElementById("display");
		var newRow = display.insertRow(row);
		var checkbox = document.createElement("INPUT");
		checkbox.type = "checkbox";

		var cell1 = newRow.insertCell(0);
		var cell2 = newRow.insertCell(1);
		var cell3 = newRow.insertCell(2);
		var cell4 = newRow.insertCell(3);

		cell4.style.textAlign = "center";

		cell1.innerHTML = className;
		cell2.innerHTML = homework;
		cell3.innerHTML = dueDate;
		cell4.appendChild(checkbox);

		row++;

		localStorage.setItem("cellOne", className);
		localStorage.setItem("cellTwo", homework);
		localStorage.setItem("cellThree", dueDate);

	}


}
onload = function() {
	document.getElementById("derp").style.display = "none";
	document.getElementById("doggo").style.display = "none";
	document.getElementById("corgi").style.display = "none";
	document.getElementById("waggy").style.display = "none";
};

function chooseDog() {
	var e = document.getElementById("dogChoose");
	var result = e.options[e.selectedIndex].value;

	if (result == "derpo")
		document.getElementById("derp").style.display = "inline";
	else if (result == "doggo")
		document.getElementById("doggo").style.display = "inline";
	else if (result == "corgi")
		document.getElementById("corgi").style.display = "inline";
	else
		document.getElementById("waggy").style.display = "inline";

	document.getElementById("chooser").style.display = "none";
}